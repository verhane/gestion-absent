@extends('layouts.admin')
@section('page-content')
    <h2>Dashboard</h2>
@endsection
