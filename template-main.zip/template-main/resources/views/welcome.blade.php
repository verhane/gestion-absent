@extends('template::layouts.guest')
@section('page-content')
    <h3>Welcome page</h3>
    <x-forms.select ></x-forms.select>
@endsection
