<?php

return [
    'champs_obligatoire_st'=>'تحقق من الحقول المطلوبة',
    'prametre_st'=>'تأكد من إختيار المستوى الصحيح',
    'request_error'=>'حدثت مشكلة. يرجى المحاولة مرة أخرى في وقت لاحق',
    'validate_error'=>'حدث خطأ في إرسال البيانات ',
    'chargement'=>"جاري التحميل",
];
