<?php
return [
    'logout' => 'تسجيل الخروج',
    'edit_profile' => "تعديل الملف الشخصي",
    'add_menu_item' => "إضافة عنصر إلى القائمة",
    'menu' => 'القائمة',
    'menus' => 'القوائم',
    'menu_item' => 'عنصر القائمة',
    'menu_icon' => 'رمز القائمة',
    'parent' => 'الأصل',
    'url' => 'الرابط',
    'menu_management' => 'إدارة القائمة',
    'url_link' => 'رابط الرابط',
    'first_level' => 'المستوى الأول',
    'role_access' => 'صلاحية الدور',
    "type_user" => "نوع المستخدم",

    // menu
    'dashboard' => 'لوحة التحكم',
    'users' => 'المستخدمين',
    'color' => 'اللون',
    'dark' => 'أسود',
    'light' => 'أبيض',

];
