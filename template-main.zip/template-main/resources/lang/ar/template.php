<?php
return [


    // footer
    'Hand-crafted & Made with' => 'مصنوع يدويًا ومصنوع من',
    'copyright' => "حقوق النشر",

    'ender_dev' => 'حدث خطأ ما حاول مرة اخرى',
];
