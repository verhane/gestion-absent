<?php
return [

    // navbar
    'logout' => 'Se deconnecte',
    'edit profile' => "Modifier le profile",


    // footer
    'Hand-crafted & Made with' => 'Fabriqué à la main et fabriqué avec',
    'copyright' => "Droits d'auteur",

    'ender_dev' => 'Une erreur est survenue veillez reessayer plus tard',
];
