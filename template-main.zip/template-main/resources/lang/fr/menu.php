<?php

return [
    'logout' => 'Se déconnecter',
    'edit_profile' => "Modifier le profile",
    'add_menu_item' => "Ajouter element",
    'menu' => 'Menu',
    'menus' => 'Menus',
    'menu_item' => 'Elément du menu',
    'menu_icon' => 'Icon du menu',
    'parent' => 'Parent',
    'url' => 'Link',
    'menu_management' => 'Gestion du menu',
    'url_link' => 'Link url',
    'first_level' => 'Premiere niveau',
    'role_access' => "droit d'accèe",
    "type_user" => "Type d'utilisateur",

    // menu
    'dashboard' => 'Tableau de bord',
    'users' => 'Utilisateurs',
    'color' => 'Couleur',
    'dark' => 'Noir',
    'light' => 'Blanc',
    'groupe_traitement' => 'Groupe de traitement',
    'type_acce' => 'Type acce'
];
