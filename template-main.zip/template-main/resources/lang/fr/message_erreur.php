<?php

return [

    'champs_obligatoire_st'=>'Verifier les champs obligatoires',
    'prametre_st'=>'Choisissez le bon paramétre dans le champ Niveau',
    'request_error'=>'Un problème est survenu. veuillez réessayer plus tard',
    'validate_error'=>'Erreur de validation du formulaire',
    'chargement'=>"Chargement en cours",
    'msg_erreur'=>"Une erreur est survenue veuillez réessayer ou actualiser la page!",
];
