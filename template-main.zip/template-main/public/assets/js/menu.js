loading_content =
    `<div class="d-flex justify-content-center align-items-center py-5">
            <div class="spinner-border" role="status">
               <span class="sr-only">Loading...</span>
            </div>
        </div>`

$(document).ready(function () {
    if ($(".menu-elements").length) initMenuSortable();
    if ($(".menu-children-elements").length) initMenuChildrenSortable();
});

function initMenuSortable() {
    $(".menu-elements").sortable({
        axis: 'y',
        update: function (event, ui) {
            updateMenuElements();
        }
    });
}

function initMenuChildrenSortable() {
    $(".menu-children-elements").sortable({
        axis: 'y',
        update: function (event, ui) {
            updateMenuChildrenElements();
        }
    });
}

function updateMenuElements() {
    let list;
    // $('[data-toggle="tooltip"]').tooltip('dispose');
    const elements = $(".menu-elements").sortable('toArray', {attribute: 'data-id'});
    if (elements.length) {
        list = elements.join();
    } else {
        list = 0;
    }

    const link = racine + "menus/saveOrder/" + list;
    $.ajax({
        type: 'GET',
        url: link,
        success: function (data) {
            console.log('well done');
        },
        error: function () {
            $.alert("Une erreur est survenue veuillez réessayer ou actualiser la page!");
        }
    });
}

function updateMenuChildrenElements() {
    let list;
    // $('[data-toggle="tooltip"]').tooltip('dispose');
    const elements = $(".menu-children-elements").sortable('toArray', {attribute: 'data-id'});
    if (elements.length) {
        list = elements.join();
    } else {
        list = 0;
    }

    const link = racine + "menus/saveOrder/" + list;
    $.ajax({
        type: 'GET',
        url: link,
        success: function (data) {
            console.log('well done');
        },
        error: function () {
            $.alert("Une erreur est survenue veuillez réessayer ou actualiser la page!");
        }
    });
}


function selectMenu(element, id) {
    $(element).on('shown.bs.collapse', function () {
        $('.collapse-item').each(function (key, item) {
            let el = $(item)
            el.children(".collapse-child").removeClass('bg-success').addClass('bg-primary');
        })
        $('#headingCollapse-' + id).addClass('bg-success').removeClass('bg-primary')
        $('#placeholder').show()
        getMenuContent(id);
    })

}

function getMenuContent(menu_id) {
    const container = "#placeholder";
    const link = 'menus/getMenuElements/' + menu_id;
    console.log(menu_id, $(container).data('id'))
    if ($(container).data('id') === menu_id)
        return
    $(container).html(loading_content);
    $.ajax({
        type: 'get',
        url: racine + link,
        success: function (data) {
            $(container).html(data);
            $(container).data('id', menu_id);
            initMenuSortable();
            initMenuChildrenSortable()
            resetInit()
            $(".btn-menu-save").removeAttr('disabled');
        },
        error: function () {
            $.alert("Une erreur est survenue veuillez réessayer ou actualiser la page!");
        }
    });
}

function deleteOfMenu(element, text) {
    let element_id = $(element).attr('element_id');
    let container = $(element).attr('container')
    let link = racine + 'menus/delete/' + element_id;
    confirmAction(link, text, function () {
        $('#' + container).hide();
    });
}

function toggleDropdownMenu() {
    $('.drop-down-menu').toggleClass('show')
    $('.dropdown-overlay').toggleClass('show')
}

